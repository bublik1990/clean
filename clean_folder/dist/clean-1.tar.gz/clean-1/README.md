# clean package

Helps you with sorting files and archives by categories:
audio, video, images, documents, archives and other